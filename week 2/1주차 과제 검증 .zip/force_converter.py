KGF_PER_NEWTON = 1 / 9.80665


def convert_force(kilonewtons):
	"""Convert kilonewtons to newtons and kilogram-force."""
	newtons = kilonewtons * 1000
	kilogram_force = newtons * KGF_PER_NEWTON
	return newtons, kilogram_force


def main():
	print("힘 단위 변환기 (kN -> N, kgf)")
	print("종료하려면 q를 입력하세요.")

	while True:
		user_input = input("힘(kN)을 입력하세요: ").strip()

		if user_input.lower() == "q":
			print("프로그램을 종료합니다.")
			break

		try:
			kilonewtons = float(user_input)
			if kilonewtons != kilonewtons:
				raise ValueError
		except ValueError:
			print("잘못된 입력입니다. 숫자 또는 q를 입력하세요.")
			continue

		newtons, kilogram_force = convert_force(kilonewtons)
		print(f"N: {newtons:,.6f} N")
		print(f"kgf: {kilogram_force:,.6f} kgf")


if __name__ == "__main__":
	main()
